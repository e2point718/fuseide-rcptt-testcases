package generate;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class GiantFuseProject {

	public static void main(String[] args) throws Exception {
		File srcFolder = new File(
				new File(GiantFuseProject.class.getProtectionDomain().getCodeSource().getLocation().toURI())
						.getParentFile().getParentFile(),
				"src");
		//10000 java files
		for(int i=0;i<100;i++){ //100 packages
			File packageFolder = new File(srcFolder,"main/java/com/mycompany/camel/spring"+i);
			if(!packageFolder.exists()){
				packageFolder.mkdirs();
			}
			for(int j=0;j<100;j++){ //100 java files in each package
				File javaFile = new File(packageFolder,"Test"+j+".java");
				if(!javaFile.exists()){
					BufferedWriter writer = new BufferedWriter(new FileWriter(javaFile));
					try{
						writer.write("package com.mycompany.camel.spring"+i+";");
						writer.newLine();
						writer.write("public class Test"+j+" {");
						writer.newLine();
						writer.write("}");
						writer.newLine();
						writer.flush();
					}finally{
						writer.close();
					}
				}
			}
		}
		//10000 XML files
		for(int i=0;i<100;i++){ 
			File packageFolder = new File(srcFolder,"main/resources/com/mycompany/camel/spring"+i);
			if(!packageFolder.exists()){
				packageFolder.mkdirs();
			}
			for(int j=0;j<100;j++){ //100 xml files in each folder
				File xmlFile = new File(packageFolder,"Test"+j+".xml");
				if(!xmlFile.exists()){
					BufferedWriter writer = new BufferedWriter(new FileWriter(xmlFile));
					try{
						writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?><test></test>");
						writer.newLine();
						writer.flush();
					}finally{
						writer.close();
					}
				}
			}
		}
		
	}

}
